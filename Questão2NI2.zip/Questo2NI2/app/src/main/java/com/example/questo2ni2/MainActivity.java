package com.example.questo2ni2;

import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText editSalario;
    CheckBox check40, check45, check50;
    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editSalario = findViewById(R.id.editSalario);
        check40 = findViewById(R.id.check40);
        check45 = findViewById(R.id.check45);
        check50 = findViewById(R.id.check50);
        btnCalcular = findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String salarioTexto = editSalario.getText().toString();

                if (salarioTexto.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Digite o salário", Toast.LENGTH_SHORT).show();
                    return;
                }

                double salario = Double.parseDouble(salarioTexto);
                double percentual = 0;

                // Apenas UM checkbox deve estar selecionado
                int checkedCount = 0;
                if (check40.isChecked()) {
                    percentual = 0.40;
                    checkedCount++;
                }
                if (check45.isChecked()) {
                    percentual = 0.45;
                    checkedCount++;
                }
                if (check50.isChecked()) {
                    percentual = 0.50;
                    checkedCount++;
                }

                if (checkedCount != 1) {
                    Toast.makeText(MainActivity.this, "Selecione apenas UM percentual", Toast.LENGTH_SHORT).show();
                    return;
                }

                double novoSalario = salario + (salario * percentual);

                Intent intent = new Intent(MainActivity.this, ResultadoActivity.class);
                Bundle bundle = new Bundle();
                bundle.putDouble("salario", salario);
                bundle.putDouble("percentual", percentual);
                bundle.putDouble("novoSalario", novoSalario);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}