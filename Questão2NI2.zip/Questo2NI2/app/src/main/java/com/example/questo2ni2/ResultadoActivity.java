package com.example.questo2ni2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultadoActivity extends AppCompatActivity {

    TextView textResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        textResultado = findViewById(R.id.textResultado);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            double salario = bundle.getDouble("salario");
            double percentual = bundle.getDouble("percentual");
            double novoSalario = bundle.getDouble("novoSalario");

            String resultado = String.format("Salário original: R$ %.2f\nAumento de: %.0f%%\nNovo salário: R$ %.2f",
                    salario, percentual * 100, novoSalario);

            textResultado.setText(resultado);
        }
    }
}