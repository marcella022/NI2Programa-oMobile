package com.example.questo1ni22;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    CheckBox checkArroz, checkLeite, checkCarne, checkFeijao, checkCoca;
    Button btnCalcular;
    TextView txtTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkArroz = findViewById(R.id.checkArroz);
        checkLeite = findViewById(R.id.checkLeite);
        checkCarne = findViewById(R.id.checkCarne);
        checkFeijao = findViewById(R.id.checkFeijao);
        checkCoca = findViewById(R.id.checkCoca);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtTotal = findViewById(R.id.txtTotal);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double total = 0;

                if (checkArroz.isChecked()) total += 2.69;
                if (checkLeite.isChecked()) total += 2.70;
                if (checkCarne.isChecked()) total += 16.70;
                if (checkFeijao.isChecked()) total += 3.38;
                if (checkCoca.isChecked()) total += 3.00;

                txtTotal.setText(String.format("Total: R$ %.2f", total));
            }
        });
    }
}
