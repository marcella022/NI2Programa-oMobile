package www.temdetudo.com.br;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    TextInputLayout nomeClienteLayout;
    TextInputEditText nomeEditText;
    Button btnProsseguir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        nomeClienteLayout = findViewById(R.id.nomeCliente);
        nomeEditText = findViewById(R.id.editTextNome);
        btnProsseguir = findViewById(R.id.btnProsseguir);

        btnProsseguir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nomeCliente = nomeEditText.getText().toString();

                Intent intent = new Intent(CadastroActivity.this, ConfirmacaoActivity.class);
                intent.putExtra("nomeCliente", nomeCliente);
                startActivity(intent);
            }
        });
    }
}