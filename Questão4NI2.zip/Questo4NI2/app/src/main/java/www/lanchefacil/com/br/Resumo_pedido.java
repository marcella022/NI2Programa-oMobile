package www.lanchefacil.com.br;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Resumo_pedido extends AppCompatActivity {
    TextView nomePedido;
    Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo_pedido); // Verifique o nome do layout aqui

        nomePedido = findViewById(R.id.NomePedido);
        btnVoltar = findViewById(R.id.btnVoltar);

        Intent intent = getIntent();
        String nome = intent.getStringExtra("nomeCliente");
        String lanche = intent.getStringExtra("lancheEscolhido");

        String resumo = "Cliente: " + nome + "\nLanche: " + lanche;
        nomePedido.setText(resumo);

        btnVoltar.setOnClickListener(v -> {
            Intent voltar = new Intent(Resumo_pedido.this, MainActivity.class);
            startActivity(voltar);
        });
    }
}
