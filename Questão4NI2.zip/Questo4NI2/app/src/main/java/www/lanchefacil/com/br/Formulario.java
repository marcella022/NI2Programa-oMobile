package www.lanchefacil.com.br;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Formulario extends AppCompatActivity {
    RadioGroup grupoLanches;
    EditText editTextNome;
    Button btnProsseguir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario); // Verifique o nome do seu layout

        grupoLanches = findViewById(R.id.grupoLanches);
        editTextNome = findViewById(R.id.editTextNome);
        btnProsseguir = findViewById(R.id.btnProsseguir);

        btnProsseguir.setOnClickListener(view -> {
            int selectedId = grupoLanches.getCheckedRadioButtonId();
            String nome = editTextNome.getText().toString();

            if (selectedId != -1 && !nome.isEmpty()) {
                RadioButton selectedLanche = findViewById(selectedId);
                String lanche = selectedLanche.getText().toString();

                Intent intent = new Intent(Formulario.this, Resumo_pedido.class);
                intent.putExtra("nomeCliente", nome);
                intent.putExtra("lancheEscolhido", lanche);
                startActivity(intent);
            } else {
                Toast.makeText(Formulario.this, "Preencha seu nome e selecione um lanche!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}