package www.lanchefacil.com.questo5ni2;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Resumo_pedido extends AppCompatActivity {

    TextView txtResumo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo_pedido); // certifique-se que o XML tem esse nome

        txtResumo = findViewById(R.id.txtResumoFinal);

        // Recuperando os dados passados pelo intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            ArrayList<String> saboresList = getIntent().getStringArrayListExtra("pizzas");
            String sabores = saboresList != null ? saboresList.toString() : "Nenhum sabor selecionado";
            String tamanho = extras.getString("tamanho");
            String pagamento = extras.getString("pagamento");

            // Criando o resumo com StringBuilder
            StringBuilder resumo = new StringBuilder();
            resumo.append("Resumo do Pedido:\n\n");
            resumo.append("Sabores selecionados: ").append(sabores).append("\n");
            resumo.append("Tamanho da pizza: ").append(tamanho).append("\n");
            resumo.append("Forma de pagamento: ").append(pagamento);

            // Mostrando no TextView
            txtResumo.setText(resumo.toString());
        }
    }
}
