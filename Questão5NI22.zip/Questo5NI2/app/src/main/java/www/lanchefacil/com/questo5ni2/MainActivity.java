package www.lanchefacil.com.questo5ni2;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    CheckBox checkCalabresa, checkMarguerita, checkPortuguesa;
    Button btnProsseguir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkCalabresa = findViewById(R.id.checkCalabresa);
        checkMarguerita = findViewById(R.id.checkMarguerita);
        checkPortuguesa = findViewById(R.id.checkPortuguesa);
        btnProsseguir = findViewById(R.id.btnProsseguirPedido1);

        btnProsseguir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> pizzasSelecionadas = new ArrayList<>();

                if (checkCalabresa.isChecked()) {
                    pizzasSelecionadas.add("Calabresa");
                }
                if (checkMarguerita.isChecked()) {
                    pizzasSelecionadas.add("Marguerita");
                }
                if (checkPortuguesa.isChecked()) {
                    pizzasSelecionadas.add("Portuguesa");
                }

                // Enviando a lista de pizzas para o próximo Activity
                Intent intent = new Intent(MainActivity.this, TamanhoPagamento.class);
                intent.putStringArrayListExtra("pizzas", pizzasSelecionadas);
                startActivity(intent);
            }
        });
    }
}