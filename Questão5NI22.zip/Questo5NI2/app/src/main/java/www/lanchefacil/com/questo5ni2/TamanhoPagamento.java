package www.lanchefacil.com.questo5ni2;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class TamanhoPagamento extends AppCompatActivity {

    RadioGroup grupoTamanho, grupoPagamento;
    RadioButton radioPeq, radioMed, radioGra, radioPix, radioCred, radioDeb;
    Button btnProsseguir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamanho_pagamento);

        // Referência dos componentes
        grupoTamanho = findViewById(R.id.Tamanho);
        grupoPagamento = findViewById(R.id.Pagamento);
        radioPeq = findViewById(R.id.radioTamPeq);
        radioMed = findViewById(R.id.radioTamMed);
        radioGra = findViewById(R.id.radioTamGra);
        radioPix = findViewById(R.id.radioPix);
        radioCred = findViewById(R.id.radioCred);
        radioDeb = findViewById(R.id.radioDeb);
        btnProsseguir = findViewById(R.id.btnProsseguirPedido2);

        // Recuperando lista de pizzas da MainActivity
        ArrayList<String> pizzasSelecionadas = getIntent().getStringArrayListExtra("pizzas");

        btnProsseguir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String tamanho = "";
                double preco = 0.0;

                int idTamanhoSelecionado = grupoTamanho.getCheckedRadioButtonId();

                if (idTamanhoSelecionado == R.id.radioTamPeq) {
                    tamanho = "Pequena";
                    preco = 30.0;
                } else if (idTamanhoSelecionado == R.id.radioTamMed) {
                    tamanho = "Média";
                    preco = 45.0;
                } else if (idTamanhoSelecionado == R.id.radioTamGra) {
                    tamanho = "Grande";
                    preco = 60.0;
                }

                String pagamento = "";
                int idPagSelecionado = grupoPagamento.getCheckedRadioButtonId();

                if (idPagSelecionado == R.id.radioPix) {
                    pagamento = "Pix";
                } else if (idPagSelecionado == R.id.radioCred) {
                    pagamento = "Crédito";
                } else if (idPagSelecionado == R.id.radioDeb) {
                    pagamento = "Débito";
                }

                // Enviar tudo para a próxima Activity
                Intent intent = new Intent(TamanhoPagamento.this, Resumo_pedido.class);
                intent.putStringArrayListExtra("pizzas", pizzasSelecionadas);
                intent.putExtra("tamanho", tamanho);
                intent.putExtra("pagamento", pagamento);
                intent.putExtra("preco", preco);
                startActivity(intent);
            }
        });
    }
}